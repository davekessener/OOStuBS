/*****************************************************************************/
/* Betriebssysteme                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                               B U Z Z E R                                 */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Mit Hilfe des "Weckers" koennen Prozesse eine bestimmte Zeit lang         */
/* schlafen und sich dann wecken lassen.                                     */
/*****************************************************************************/

#ifndef __Buzzer_include__
#define __Buzzer_include__

/* Hier muesst ihr selbst Code vervollstaendigen */ 

class Buzzer
/* Hier muesst ihr selbst Code vervollstaendigen */ 
{
private:
    Buzzer(const Buzzer &copy); // Verhindere Kopieren
/* Hier muesst ihr selbst Code vervollstaendigen */ 
};

#endif
