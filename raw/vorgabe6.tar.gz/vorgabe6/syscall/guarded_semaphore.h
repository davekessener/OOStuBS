/*****************************************************************************/
/* Betriebssysteme                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                   G U A R D E D _ S E M A P H O R E                       */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Systemaufrufschnittstelle zum Semaphor.                                   */
/*****************************************************************************/

#ifndef __Guarded_Semaphore_include__
#define __Guarded_Semaphore_include__

/* Hier muesst ihr selbst Code vervollstaendigen */ 
        
class Guarded_Semaphore 
/* Hier muesst ihr selbst Code vervollstaendigen */         
 {
private:
    Guarded_Semaphore (const Guarded_Semaphore &copy); // Verhindere Kopieren
/* Hier muesst ihr selbst Code vervollstaendigen */          
 };

#endif
