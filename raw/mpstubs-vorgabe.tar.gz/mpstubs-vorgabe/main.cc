// Bereits in OO-StuBS vorhandene Header
#include "device/keyboard.h"
#include "device/cgastr.h"
#include "machine/pic.h"
#include "machine/cpu.h"                
#include "machine/plugbox.h"
#include "guard/guard.h"

// Neue Header für MP-StuBS
#include "object/debug.h"
#include "machine/smpsys.h"
#include "machine/lapic.h"
#include "machine/ioapic.h"
#include "machine/spinlock.h"

Plugbox plugbox;                
PIC pic;
CPU cpu;
CGA_Stream kout;
Keyboard keyboard;
Guard guard;

Spinlock kout_lock;

typedef char BootStack[4096]; // 4K Boot-Stack ...
BootStack cpu_stack[CPU_MAX]; // ... fuer jeden Kern

//static unsigned long appl_stack[4096];

/* main-Funktion für den Bootstrapprozessor */
extern "C" int main()
{
    keyboard.Keyboard::plugin();

    /* Pruefen ob wir ein SMP-System haben.
       Falls ja, werden die anderen CPUs gebootet, sowie
       benötigte Geräteinterrupts im IOAPIC initialisiert */

    bool isSMP = smp.isSMPSystem();
    unsigned int numCPUs = smp.getNumberOfCPUs();
    unsigned int numIOAPICs = smp.getNumberOfIOAPICs();
	
    if (isSMP) {
	for (unsigned int i = 0; i < numCPUs; i++)
	    smp.bootCPU(i, &(cpu_stack[(i+1)*256]));
	for (unsigned int i = 0; i < numIOAPICs; i++)
	    ioapic[i].init();

    }
	
		
    LOCK
    DBG << "Number of online CPUs: " << smp.getNumberOfOnlineCPUs() << endl;
    UNLOCK

    cpu.enable_int();

    /*
     * Hier könnt ihr loslegen...
     */

    for (;;);

    return 0;
}


/* main-Funktion für die anderen (Applikations-)Prozessoren */
extern "C" int main_ap()
{
    // local APIC Initialisierung und ID erfragen
    lapic.init();

    unsigned char lapic_id = lapic.getLAPICID();

    // Falls die local APIC ID des APs, der gerade booten soll, ungleich der eigenen ID ist,
    // muss der Bootvorgang extrem lange gedauert haben. Wir halten den AP an.
    smp.bootingAPLock.lock();
    if (smp.bootingAP != lapic_id) {
      LOCK
      DBG << "CPU with local APIC ID " << lapic_id << " halted. Booting took too long!" << endl;
      UNLOCK
      smp.bootingAPLock.unlock();
      cpu.halt();
    }

    unsigned char llapic_id = (1 << smp.getAndIncNextLogicalAPICID());
    
    LOCK
    DBG << "CPU " << (int) smp.getCPUID() << " got called out, setting logical APIC ID to " << (int) llapic_id << endl;
    UNLOCK

    lapic.setLogicalLAPICID(llapic_id);

    // dem Boot-Prozessor mitteilen, dass dieser Prozessor nun laeuft.
    smp.bootingAP = 0xff;
    smp.bootingAPLock.unlock();

    cpu.enable_int();

    /*
     * Hier könnt ihr loslegen...
     */

    for (;;);

    return 0;
}

